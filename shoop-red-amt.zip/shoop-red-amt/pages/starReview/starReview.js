Page({
 
    data: {
        starstext:["烂片","失望","一般","不错","超赞"],
        normalSrc: '../images/star/star01.png',
        selectedSrc: '../images/star/star03.png',
        halfSrc: '../images/star/star02.png',
        inputValue:"",
        score: 5,
        id:"",
        movieName:"这是一个标题"
    },

    onLoad:function(options){
        var _this = this;
        // _this.setData({
        //     id:options.id,
        //     movieName:options.name
        // })
    },
    // ------------------新的星星选择--------------------
    starLeftBtn:function(e){
        var _this = this;
        var score = e.currentTarget.dataset.score;
        console.log(score)
        _this.setData({
            score:score
        })
    },
    starRightBtn:function(e){
        var _this = this;
        var score = e.currentTarget.dataset.score;
        console.log(score)
        _this.setData({
            score:score
        })
    },
    // 输入
    chengeInput:function(e){
        var _this = this;
        // console.log(e.detail.value)
        var value = e.detail.value;
        _this.setData({
            inputValue:value
        })
    },
    // 提交评论按钮
    sendBtn:function(){
        var _this = this;
        var value = _this.data.inputValue;
        value.replace(/\s/g,"");
        if(value==""){
            wx.showToast({
                icon:"none",
                title: '评论内容不能为空！',
            })
            return;
        }
        if(_this.data.score=='0'){
            wx.showToast({
                icon:"none",
                title: '请打分',
            })
            return;
        }
        // _this.setComment();
    }
   })