// pages/shop/shop.js
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        top:0,
        left:0,
        redStatus:true,
        shopx :0,
        shopy :0,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.setData({
            shopx:38,
            shopy:app.globalData.hh - 60
        })
    },

    addBtn:function(e){
        var _this = this;
        var shopy = _this.data.shopy;
        var shopx = _this.data.shopx;
        this.finger = {};
      var topPoint = {};
      this.finger['x'] = e.touches["0"].clientX; //点击的位置
      this.finger['y'] = e.touches["0"].clientY;

      if (this.finger['y'] < shopy) {
        topPoint['y'] = this.finger['y'] - 150;
      } else {
        topPoint['y'] = shopy - 150;
      }
      topPoint['x'] = Math.abs(this.finger['x'] - shopx) / 2;

      if (this.finger['x'] > shopx) {
        topPoint['x'] = (this.finger['x'] - shopx) / 2 + shopx;
      } else { //
        topPoint['x'] = (shopx - this.finger['x']) / 2 + this.finger['x'];
      }
      this.busPos = {
          x : shopx,
          y : shopy
      }
      this.linePos = app.bezier([this.busPos, topPoint, this.finger], 50);
      this.startAnimation(e);
    },
    
    startAnimation: function (e) {
        var index = 0,
          that = this,
          bezier_points = that.linePos['bezier_points'];
  
        this.setData({
            redStatus: false,
            left: that.finger['x'],
            top: that.finger['y']
        })
        var len = bezier_points.length;
        index= len;
        this.timer = setInterval(function() {
          index--;
          that.setData({
              left: bezier_points[index]['x'],
              top: bezier_points[index]['y']
          })
          if (index <= 1) {
              clearInterval(that.timer);
              that.setData({
                redStatus: true,
              })
          }
      }, 10);
      },
})