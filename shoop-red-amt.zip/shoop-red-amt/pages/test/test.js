// pages/test/test.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        height:0,
        sortList:[0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9],
        sortIdx:0,
        smallList:[1,2,3,4,5,6,7],
        smallindex:0,
        datalist:[
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                        {
                            a:[{b:456}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                        {count:2}
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                        {
                            a:[{b:456}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                        {count:2}
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1}
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                        {
                            a:[{b:456}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                        {count:2}
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                        {
                            a:[{b:456}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                        {count:2}
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                    ]
                }
            },
            {
                skulist:{
                    list:[
                        {
                            a:[{b:123}]     
                        },
                        {
                            a:[{b:456}]     
                        },
                    ],
                    sku_mu_list:[
                        {count:1},
                        {count:2}
                    ]
                }
            },
        ],
        spceIndex:-1,
    },

    /**
     * 生命周期函数--监听页面加载
     * {
     *  skulist:{
     *      list:[
     *          {
     *              a:[{b:123}]     
     *          },
     *          {
     *              a:[{b:456}]     
     *          },
     *      ],
     *      sku_mu_list:{
     *          123:{count:1},
     *          456:{count:2}
     *      }
     *  }
     * }
     */
    onLoad: function (options) {
        var that = this;
        wx.getSystemInfo({
            success: function (res) {
              let clientHeight = res.windowHeight;
              let clientWidth = res.windowWidth;
              let ratio = 750 / clientWidth;
              let height = clientHeight * ratio;
              that.setData({
                height: height-120
              });
              console.log(height)
            }
          });
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    // 展开点击
    morebtn:function(e){
        var _this = this;
        var index = e.currentTarget.dataset.index;
        if(index==_this.data.spceIndex){
            _this.setData({
                spceIndex:-1
            })
        }else{
            _this.setData({
                spceIndex:index
            })
        }
        
    },
    // 多形式减减
    specLessBtn:function(e){
        // console.log(e)
        var _this = this;
        var bindex = e.currentTarget.dataset.bindex;
        var sindex = e.currentTarget.dataset.sindex;
        var count = e.currentTarget.dataset.count;
        var sku = e.currentTarget.dataset.sku;
        if(count<1){
            return;
        }else{
            count=count-1;
            var temp = "datalist["+bindex+"].skulist.sku_mu_list["+sindex+"].count"
            _this.setData({
                [temp]:count,
            })
        }
        
    },
    // 多形式加加
    specAddBtn:function(e){
        // console.log(e)
        var _this = this;
        var bindex = e.currentTarget.dataset.bindex;
        var sindex = e.currentTarget.dataset.sindex;
        var count = e.currentTarget.dataset.count;
        var sku = e.currentTarget.dataset.sku;
        count=count+1;
        var temp = "datalist["+bindex+"].skulist.sku_mu_list["+sindex+"].count"
        _this.setData({
            [temp]:count,
        })
        // console.log(_this.data.datalist[bindex])
    },
})