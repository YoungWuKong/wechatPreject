// pages/tabLineAmt/tabLineAmt.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        arr:[
            "1234","12","123456","98756","8521","963","8426","987621"
        ],
        tabIndex:0,
        left:"",
        moveLeft:0,
        oldLeft:0,
        iosStatus:false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var _this = this;
        wx.getSystemInfo({
            success: function (res) {  // 获取手机信息
                if(res.system[0]=='i'){
                    _this.setData({
                        iosStatus:true
                    }) 
                }
            }
          })
        setTimeout(()=>{
            _this.changeline()
        },100)
    },

    // 顶部tab选择
    selectTab:function(e){
        var _this = this;
        const query = wx.createSelectorQuery();
        query.select('.tabTrue').boundingClientRect()
        query.exec(function (res) {
            // console.log("上一个tabTrue的位置")
            // console.log(res[0].left)  
            var width = res[0].width?res[0].width:'0';
            _this.setData({
                oldLeft:res[0].left+(width-25)/2
            })
        })
        var index = parseInt(e.currentTarget.dataset.index);
        _this.setData({
            tabIndex:index,
        })
        // _this.getEnterpriseInfo();
        _this.changeline(e)
    },


    //   ---------滑动---------
    changeTab:function(e){
        //console.log(e)
        this.setData({
            currentIndex: e.currentTarget.dataset.aa
        })
        this.changeline()

    },
    changeline:function(){
        const query = wx.createSelectorQuery()
        var _this = this
        query.select('.tabTrue').boundingClientRect()
        query.exec(function (res) {
            // console.log("点击选择标签")
            var width = res[0].width?res[0].width:'0';
            var left = 0;
            var newLeft = 0;
            if(width>32){
                left = (width-32)/2
            }
            if(_this.data.oldLeft!=0){
                newLeft = (res[0].left)-_this.data.oldLeft;
                // console.log(newLeft)
                _this.setData({
                    left: _this.data.left+newLeft+(width-25)/2
                })
            }else{
                _this.setData({
                    left: res[0].left-_this.data.moveLeft+left-12
                })
            }
        })
        // console.log("left数值")
        // console.log(_this.data.left)
    },
    scrollEvent:function(e){
        // console.log(e.detail.deltaX)
        var _this = this;
        // console.log(_this.data.left)
        _this.setData({
            moveLeft:e.detail.scrollLeft
        })
    },
})